namespace DeltaAutoKey.Models;

public sealed class PageAnalysis
{
    public bool RequiresPayment { get; set; }

    public bool RequiresDownload { get; set; }

    public bool HasCaptcha { get; set; }

    public bool HasContinueButton { get; set; }

    public bool HasTimer { get; set; }

    public bool HasKey { get; set; }

    public string? Key { get; set; }

    public string Status { get; set; } = "";

    public bool IsDangerous =>
        RequiresPayment || RequiresDownload;
}
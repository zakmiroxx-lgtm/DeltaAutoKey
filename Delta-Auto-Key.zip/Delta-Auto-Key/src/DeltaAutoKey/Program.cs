using System;
using System.Windows.Forms;
using DeltaAutoKey.Forms;

namespace DeltaAutoKey;

internal static class Program
{
    [STAThread]
    private static void Main()
    {
        ApplicationConfiguration.Initialize();

        Application.Run(new MainForm());
    }
}
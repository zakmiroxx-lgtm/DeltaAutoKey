using System.Drawing;
using System.Windows.Forms;
using DeltaAutoKey.Models;
using DeltaAutoKey.Services;
using Microsoft.Web.WebView2.WinForms;

namespace DeltaAutoKey.Forms;

public sealed class MainForm : Form
{
    private readonly WebView2 browser = new();

    private readonly TextBox urlBox = new();
    private readonly TextBox keyBox = new();

    private readonly Label statusLabel = new();

    private readonly Button startButton = new();
    private readonly Button stopButton = new();
    private readonly Button copyButton = new();

    private readonly PageAnalyzer analyzer = new();

    private BrowserService? browserService;

    private bool running;

    public MainForm()
    {
        Text = "Delta Auto Key v1.0";

        Width = 1150;
        Height = 800;

        MinimumSize = new Size(900, 600);

        StartPosition = FormStartPosition.CenterScreen;

        BackColor = Color.FromArgb(18, 18, 24);

        ForeColor = Color.White;

        BuildInterface();

        Shown += async (_, _) =>
        {
            await InitializeAsync();
        };
    }

    private void BuildInterface()
    {
        var panel = new Panel
        {
            Dock = DockStyle.Top,
            Height = 175,
            BackColor = Color.FromArgb(28, 28, 36)
        };

        var title = new Label
        {
            Text = "DELTA AUTO KEY",
            Font = new Font(
                "Segoe UI",
                18,
                FontStyle.Bold
            ),
            ForeColor = Color.DeepSkyBlue
        };

        title.SetBounds(15, 10, 400, 40);

        urlBox.SetBounds(15, 60, 760, 30);

        urlBox.PlaceholderText =
            "Вставьте ссылку Platoboost / Platorelay";

        startButton.Text = "START";
        startButton.SetBounds(790, 60, 100, 30);

        stopButton.Text = "STOP";
        stopButton.SetBounds(900, 60, 100, 30);

        statusLabel.Text = "STATUS: Waiting";

        statusLabel.ForeColor = Color.LightGreen;

        statusLabel.SetBounds(15, 105, 1000, 25);

        keyBox.SetBounds(15, 140, 760, 25);

        keyBox.ReadOnly = true;

        keyBox.PlaceholderText =
            "Ключ пока не получен";

        copyButton.Text = "COPY KEY";

        copyButton.SetBounds(790, 140, 120, 25);

        panel.Controls.Add(title);
        panel.Controls.Add(urlBox);
        panel.Controls.Add(startButton);
        panel.Controls.Add(stopButton);
        panel.Controls.Add(statusLabel);
        panel.Controls.Add(keyBox);
        panel.Controls.Add(copyButton);

        browser.Dock = DockStyle.Fill;

        Controls.Add(browser);
        Controls.Add(panel);

        startButton.Click += (_, _) => Start();

        stopButton.Click += (_, _) => Stop();

        copyButton.Click += (_, _) => CopyKey();
    }

    private async Task InitializeAsync()
    {
        browserService = new BrowserService(browser);

        browserService.SecurityBlocked += reason =>
        {
            BeginInvoke(() =>
            {
                Block(reason);
            });
        };

        browserService.PageLoaded += text =>
        {
            BeginInvoke(() =>
            {
                AnalyzePage(text);
            });
        };

        try
        {
            await browserService.InitializeAsync();

            SetStatus("Браузер готов", Color.LightGreen);
        }
        catch (Exception ex)
        {
            SetStatus(
                "Ошибка запуска браузера",
                Color.OrangeRed
            );

            MessageBox.Show(
                ex.Message,
                "Ошибка WebView2",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error
            );
        }
    }

    private void Start()
    {
        if (browserService == null)
        {
            MessageBox.Show(
                "Браузер ещё не готов"
            );

            return;
        }

        string url = urlBox.Text.Trim();

        if (string.IsNullOrWhiteSpace(url))
        {
            MessageBox.Show(
                "Вставьте ссылку Platoboost"
            );

            return;
        }

        running = true;

        keyBox.Clear();

        SetStatus(
            "Открытие страницы...",
            Color.LightBlue
        );

        browserService.Navigate(url);
    }

    private void Stop()
    {
        running = false;

        browserService?.Stop();

        SetStatus(
            "Процесс остановлен",
            Color.Orange
        );
    }

    private void AnalyzePage(string text)
    {
        if (!running)
            return;

        PageAnalysis result = analyzer.Analyze(text);

        if (result.IsDangerous)
        {
            Block(
                "Страница требует оплаты или скачивания"
            );

            return;
        }

        if (result.HasKey && result.Key != null)
        {
            keyBox.Text = result.Key;

            running = false;

            SetStatus(
                "Возможный ключ найден",
                Color.LightGreen
            );

            return;
        }

        if (result.HasCaptcha)
        {
            SetStatus(
                "Требуется ручная CAPTCHA",
                Color.Orange
            );

            return;
        }

        SetStatus(
            result.Status,
            Color.LightBlue
        );
    }

    private void Block(string reason)
    {
        if (!running)
            return;

        running = false;

        browserService?.Stop();

        SetStatus(
            "ОПАСНЫЙ ЭТАП ЗАБЛОКИРОВАН",
            Color.Red
        );

        MessageBox.Show(
            "⚠️ Этап требует оплаты или скачивания. " +
            "Действие заблокировано ради безопасности.\n\n" +
            reason,
            "Security Alert",
            MessageBoxButtons.OK,
            MessageBoxIcon.Warning
        );
    }

    private void CopyKey()
    {
        if (string.IsNullOrWhiteSpace(keyBox.Text))
        {
            MessageBox.Show(
                "Ключ ещё не найден"
            );

            return;
        }

        Clipboard.SetText(keyBox.Text);

        SetStatus(
            "Ключ скопирован",
            Color.LightGreen
        );
    }

    private void SetStatus(
        string message,
        Color color)
    {
        statusLabel.Text = "STATUS: " + message;

        statusLabel.ForeColor = color;
    }
}
namespace DeltaAutoKey.Services;

public sealed class SecurityService
{
    private static readonly string[] PaymentDomains =
    {
        "paypal.com",
        "stripe.com",
        "checkout.stripe.com",
        "buy.stripe.com",
        "pay.google.com",
        "payments.google.com",
        "checkout.com",
        "paddle.com",
        "lemonsqueezy.com"
    };

    private static readonly string[] BlockedExtensions =
    {
        ".exe",
        ".msi",
        ".apk",
        ".zip",
        ".rar",
        ".7z",
        ".bat",
        ".cmd",
        ".ps1",
        ".scr",
        ".com",
        ".msix",
        ".appx"
    };

    public bool IsUrlAllowed(string url)
    {
        if (!Uri.TryCreate(
            url,
            UriKind.Absolute,
            out Uri? uri))
        {
            return false;
        }

        if (uri.Scheme != Uri.UriSchemeHttps)
            return false;

        string host = uri.Host.ToLowerInvariant();

        foreach (string domain in PaymentDomains)
        {
            if (host == domain ||
                host.EndsWith("." + domain))
            {
                return false;
            }
        }

        string path = uri.AbsolutePath.ToLowerInvariant();

        foreach (string extension in BlockedExtensions)
        {
            if (path.EndsWith(extension))
                return false;
        }

        return true;
    }
}
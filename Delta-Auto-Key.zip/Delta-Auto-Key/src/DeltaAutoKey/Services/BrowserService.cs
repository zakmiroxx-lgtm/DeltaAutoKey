using System;
using System.Drawing;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;

using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

namespace DeltaAutoKey.Services;

public sealed class BrowserService
{
    private readonly WebView2 browser;

    private readonly SecurityService security = new();

    private bool initialized;

    public event Action<string>? SecurityBlocked;

    public event Action<string>? PageLoaded;

    public BrowserService(WebView2 browser)
    {
        this.browser = browser;
    }

    public async Task InitializeAsync()
    {
        if (initialized)
            return;

        await browser.EnsureCoreWebView2Async();

        ConfigureBrowser(browser);

        initialized = true;
    }

    private void ConfigureBrowser(WebView2 view)
    {
        CoreWebView2 core = view.CoreWebView2;

        core.Settings.AreDevToolsEnabled = false;

        core.Settings.AreDefaultContextMenusEnabled = false;

        core.Settings.AreBrowserAcceleratorKeysEnabled = false;

        core.Settings.IsPasswordAutosaveEnabled = false;

        core.Settings.IsGeneralAutofillEnabled = false;

        core.Settings.AreHostObjectsAllowed = false;

        core.Settings.IsWebMessageEnabled = false;

        core.Settings.IsStatusBarEnabled = false;

        // Блокировка скачиваний

        core.DownloadStarting += (_, e) =>
        {
            e.Cancel = true;

            SecurityBlocked?.Invoke(
                "Скачивание файла заблокировано"
            );
        };

        // Проверка переходов

        core.NavigationStarting += (_, e) =>
        {
            if (!security.IsUrlAllowed(e.Uri))
            {
                e.Cancel = true;

                SecurityBlocked?.Invoke(
                    "Заблокирован небезопасный переход: " +
                    e.Uri
                );
            }
        };

        // Запрет запуска сторонних приложений

        core.LaunchingExternalUriScheme += (_, e) =>
        {
            e.Cancel = true;

            SecurityBlocked?.Invoke(
                "Запуск внешнего приложения заблокирован"
            );
        };

        // Запрет разрешений

        core.PermissionRequested += (_, e) =>
        {
            e.State = CoreWebView2PermissionState.Deny;
        };

        // Обработка рекламных окон

        core.NewWindowRequested += async (_, e) =>
        {
            e.Handled = true;

            if (!security.IsUrlAllowed(e.Uri))
            {
                SecurityBlocked?.Invoke(
                    "Небезопасное рекламное окно заблокировано"
                );

                return;
            }

            await OpenAdvertisementWindowAsync(e.Uri);
        };

        // Анализ страниц

        core.NavigationCompleted += async (_, e) =>
        {
            if (!e.IsSuccess)
                return;

            // Анализируем только основную страницу,
            // рекламные окна не участвуют в поиске ключа.

            if (view != browser)
                return;

            try
            {
                string text = await GetPageTextAsync();

                PageLoaded?.Invoke(text);
            }
            catch (Exception ex)
            {
                SecurityBlocked?.Invoke(
                    "Ошибка анализа страницы: " +
                    ex.Message
                );
            }
        };
    }

    private async Task OpenAdvertisementWindowAsync(string url)
    {
        Form adWindow = new Form
        {
            Text = "Delta Auto Key - Advertisement",

            Width = 950,
            Height = 700,

            StartPosition = FormStartPosition.CenterScreen,

            BackColor = Color.FromArgb(20, 20, 25)
        };

        WebView2 adBrowser = new WebView2
        {
            Dock = DockStyle.Fill
        };

        adWindow.Controls.Add(adBrowser);

        adWindow.Show();

        try
        {
            await adBrowser.EnsureCoreWebView2Async();

            ConfigureBrowser(adBrowser);

            adBrowser.CoreWebView2.Navigate(url);
        }
        catch (Exception ex)
        {
            adWindow.Close();

            SecurityBlocked?.Invoke(
                "Ошибка открытия рекламы: " +
                ex.Message
            );
        }
    }

    public void Navigate(string url)
    {
        if (!initialized || browser.CoreWebView2 == null)
        {
            SecurityBlocked?.Invoke(
                "Браузер не готов"
            );

            return;
        }

        if (!security.IsUrlAllowed(url))
        {
            SecurityBlocked?.Invoke(
                "Ссылка не прошла проверку безопасности"
            );

            return;
        }

        browser.CoreWebView2.Navigate(url);
    }

    public void Stop()
    {
        if (!initialized)
            return;

        browser.CoreWebView2?.Stop();
    }

    private async Task<string> GetPageTextAsync()
    {
        if (browser.CoreWebView2 == null)
            return "";

        string script = """
            (() => {
                return document.body?.innerText || "";
            })()
            """;

        string json =
            await browser.CoreWebView2.ExecuteScriptAsync(
                script
            );

        return JsonSerializer.Deserialize<string>(json) ?? "";
    }
}
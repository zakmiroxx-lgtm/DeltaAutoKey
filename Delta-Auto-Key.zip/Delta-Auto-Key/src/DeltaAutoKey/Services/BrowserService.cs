using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

namespace DeltaAutoKey.Services;

public sealed class BrowserService
{
    private readonly WebView2 browser;

    private readonly SecurityService security = new();

    public event Action<string>? SecurityBlocked;

    public event Action<string>? PageLoaded;

    public BrowserService(WebView2 browser)
    {
        this.browser = browser;
    }

    public async Task InitializeAsync()
    {
        await browser.EnsureCoreWebView2Async();

        CoreWebView2 core = browser.CoreWebView2;

        core.Settings.AreDevToolsEnabled = false;
        core.Settings.AreDefaultContextMenusEnabled = false;
        core.Settings.IsPasswordAutosaveEnabled = false;
        core.Settings.IsGeneralAutofillEnabled = false;
        core.Settings.AreHostObjectsAllowed = false;
        core.Settings.IsWebMessageEnabled = false;

        core.DownloadStarting += (_, e) =>
        {
            e.Cancel = true;

            SecurityBlocked?.Invoke(
                "Попытка скачивания файла"
            );
        };

        core.NewWindowRequested += (_, e) =>
        {
            e.Handled = true;

            SecurityBlocked?.Invoke(
                "Всплывающее окно заблокировано"
            );
        };

        core.NavigationStarting += (_, e) =>
        {
            if (!security.IsUrlAllowed(e.Uri))
            {
                e.Cancel = true;

                SecurityBlocked?.Invoke(
                    "Запрещённый URL: " + e.Uri
                );
            }
        };

        core.LaunchingExternalUriScheme += (_, e) =>
        {
            e.Cancel = true;

            SecurityBlocked?.Invoke(
                "Запуск внешнего приложения заблокирован"
            );
        };

        core.PermissionRequested += (_, e) =>
        {
            e.State = CoreWebView2PermissionState.Deny;
        };

        core.FileSystemHandlePermissionRequested += (_, e) =>
        {
            e.State =
                CoreWebView2FileSystemHandlePermissionState.Deny;
        };

        core.NavigationCompleted += async (_, e) =>
        {
            if (!e.IsSuccess)
                return;

            string text = await GetPageTextAsync();

            PageLoaded?.Invoke(text);
        };
    }

    public void Navigate(string url)
    {
        if (!security.IsUrlAllowed(url))
        {
            SecurityBlocked?.Invoke(
                "Ссылка не прошла проверку безопасности"
            );

            return;
        }

        browser.CoreWebView2.Navigate(url);
    }

    public void Stop()
    {
        browser.CoreWebView2?.Stop();
    }

    private async Task<string> GetPageTextAsync()
    {
        string script = """
            (() => {
                return document.body?.innerText || "";
            })()
            """;

        string json =
            await browser.CoreWebView2.ExecuteScriptAsync(
                script
            );

        return System.Text.Json.JsonSerializer
            .Deserialize<string>(json) ?? "";
    }
}
using System;
using System.Text.Json;
using System.Threading.Tasks;

using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

namespace DeltaAutoKey.Services;

public sealed class BrowserService
{
    private readonly WebView2 browser;

    private readonly SecurityService security = new();

    private bool initialized = false;

    public event Action<string>? SecurityBlocked;

    public event Action<string>? PageLoaded;

    public BrowserService(WebView2 browser)
    {
        this.browser = browser;
    }

    public async Task InitializeAsync()
    {
        if (initialized)
            return;

        await browser.EnsureCoreWebView2Async();

        CoreWebView2 core = browser.CoreWebView2;

        // Настройки безопасности

        core.Settings.AreDevToolsEnabled = false;

        core.Settings.AreDefaultContextMenusEnabled = false;

        core.Settings.AreBrowserAcceleratorKeysEnabled = false;

        core.Settings.IsPasswordAutosaveEnabled = false;

        core.Settings.IsGeneralAutofillEnabled = false;

        core.Settings.AreHostObjectsAllowed = false;

        core.Settings.IsWebMessageEnabled = false;

        core.Settings.IsStatusBarEnabled = false;

        // Полная блокировка скачиваний через WebView2

        core.DownloadStarting += (_, e) =>
        {
            e.Cancel = true;

            SecurityBlocked?.Invoke(
                "Загрузка файла заблокирована"
            );
        };

        // Запрет всплывающих окон

        core.NewWindowRequested += (_, e) =>
        {
            e.Handled = true;

            SecurityBlocked?.Invoke(
                "Всплывающее окно заблокировано"
            );
        };

        // Проверка каждого перехода

        core.NavigationStarting += (_, e) =>
        {
            if (!security.IsUrlAllowed(e.Uri))
            {
                e.Cancel = true;

                SecurityBlocked?.Invoke(
                    "Заблокирован небезопасный переход: " +
                    e.Uri
                );
            }
        };

        // Запрет открытия внешних приложений

        core.LaunchingExternalUriScheme += (_, e) =>
        {
            e.Cancel = true;

            SecurityBlocked?.Invoke(
                "Запуск внешнего приложения заблокирован"
            );
        };

        // Запрет запросов разрешений

        core.PermissionRequested += (_, e) =>
        {
            e.State = CoreWebView2PermissionState.Deny;
        };

        // Обработка загрузки страницы

        core.NavigationCompleted += async (_, e) =>
        {
            if (!e.IsSuccess)
                return;

            try
            {
                string text = await GetPageTextAsync();

                PageLoaded?.Invoke(text);
            }
            catch (Exception ex)
            {
                SecurityBlocked?.Invoke(
                    "Ошибка анализа страницы: " +
                    ex.Message
                );
            }
        };

        initialized = true;
    }

    public void Navigate(string url)
    {
        if (!initialized || browser.CoreWebView2 == null)
        {
            SecurityBlocked?.Invoke(
                "Браузер ещё не инициализирован"
            );

            return;
        }

        if (!security.IsUrlAllowed(url))
        {
            SecurityBlocked?.Invoke(
                "Ссылка не прошла проверку безопасности"
            );

            return;
        }

        browser.CoreWebView2.Navigate(url);
    }

    public void Stop()
    {
        if (!initialized)
            return;

        browser.CoreWebView2?.Stop();
    }

    private async Task<string> GetPageTextAsync()
    {
        if (browser.CoreWebView2 == null)
            return "";

        string script = """
            (() => {
                return document.body?.innerText || "";
            })()
            """;

        string json =
            await browser.CoreWebView2.ExecuteScriptAsync(
                script
            );

        return JsonSerializer.Deserialize<string>(json) ?? "";
    }
}
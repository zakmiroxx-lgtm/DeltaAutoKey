using DeltaAutoKey.Models;

namespace DeltaAutoKey.Services;

public sealed class PageAnalyzer
{
    private readonly KeyDetector keyDetector = new();

    private static readonly string[] PaymentWords =
    {
        "payment required",
        "credit card",
        "debit card",
        "bank card",
        "purchase required",
        "paid subscription",
        "start free trial",
        "subscribe to continue",
        "оплатите",
        "банковская карта",
        "платная подписка"
    };

    private static readonly string[] DownloadWords =
    {
        "download required",
        "install required",
        "download app to continue",
        "install app to continue",
        "download and run",
        "скачайте приложение",
        "установите приложение"
    };

    public PageAnalysis Analyze(string text)
    {
        var result = new PageAnalysis();

        if (string.IsNullOrWhiteSpace(text))
        {
            result.Status = "Страница пуста";
            return result;
        }

        string lower = text.ToLowerInvariant();

        result.RequiresPayment =
            PaymentWords.Any(lower.Contains);

        result.RequiresDownload =
            DownloadWords.Any(lower.Contains);

        result.HasCaptcha =
            lower.Contains("captcha") ||
            lower.Contains("verify you are human") ||
            lower.Contains("i'm not a robot");

        result.HasContinueButton =
            lower.Contains("continue") ||
            lower.Contains("next step") ||
            lower.Contains("продолжить");

        result.HasTimer =
            lower.Contains("please wait") ||
            lower.Contains("seconds remaining") ||
            lower.Contains("подождите");

        string? key = keyDetector.Detect(text);

        if (key != null)
        {
            result.HasKey = true;
            result.Key = key;
            result.Status = "Возможный ключ обнаружен";

            return result;
        }

        if (result.IsDangerous)
        {
            result.Status =
                "Обнаружен опасный этап";

            return result;
        }

        if (result.HasCaptcha)
        {
            result.Status =
                "Требуется ручная проверка CAPTCHA";

            return result;
        }

        if (result.HasTimer)
        {
            result.Status =
                "Обнаружен таймер";

            return result;
        }

        if (result.HasContinueButton)
        {
            result.Status =
                "Обнаружена кнопка продолжения";

            return result;
        }

        result.Status =
            "Страница открыта";
        
        return result;
    }
}
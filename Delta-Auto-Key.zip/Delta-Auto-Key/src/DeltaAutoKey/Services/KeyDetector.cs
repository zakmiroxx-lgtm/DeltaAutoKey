using System.Text.RegularExpressions;

namespace DeltaAutoKey.Services;

public sealed class KeyDetector
{
    private static readonly Regex KeyRegex = new(
        @"(?:delta\s*key|your\s*key|executor\s*key)" +
        @"\s*[:：]\s*([A-Za-z0-9_-]{16,128})",
        RegexOptions.IgnoreCase |
        RegexOptions.Compiled
    );

    public string? Detect(string text)
    {
        if (string.IsNullOrWhiteSpace(text))
            return null;

        Match match = KeyRegex.Match(text);

        if (!match.Success)
            return null;

        return match.Groups[1].Value;
    }
}